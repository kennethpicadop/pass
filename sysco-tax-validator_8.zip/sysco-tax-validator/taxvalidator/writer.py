"""Escribe el Excel de salida: codigo recomendado + justificacion + confianza + hoja resumen."""
from __future__ import annotations

from collections import Counter

from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .engine import Result
from .xlsx_io import load_workbook_any

TAX_COL = "Sales Tax Indicator Code - TAX Review"
JUST_COL = "TAX Review - Justification & Source"
CONF_COL = "TAX Review - Confidence"
RAISE_COL = "TAX Review - What would raise confidence"

FILLS = {"High": "C6EFCE", "Medium": "FFEB9C", "Low": "F8CBAD"}


def write_output(src_path: str, out_path: str, headers_row: list[str], results: list[Result],
                 file_label: str, ref_has_map: bool, sheet_index: int = 0, override_note: str = ""):
    wb = load_workbook_any(src_path)
    ws = wb.worksheets[sheet_index]
    hdr = [("" if c.value is None else str(c.value).strip()) for c in ws[1]]

    if TAX_COL in hdr:
        col = hdr.index(TAX_COL) + 1
    else:
        col = len(hdr) + 1
        ws.cell(row=1, column=col, value=TAX_COL)
    # dos columnas nuevas al lado
    if col < ws.max_column:
        ws.insert_cols(col + 1, 3)
    ws.cell(row=1, column=col + 1, value=JUST_COL)
    ws.cell(row=1, column=col + 2, value=CONF_COL)
    ws.cell(row=1, column=col + 3, value=RAISE_COL)

    head_font = Font(bold=True)
    for c in (col, col + 1, col + 2, col + 3):
        cell = ws.cell(row=1, column=c)
        cell.font = head_font
        cell.fill = PatternFill("solid", fgColor="DDEBF7")
        cell.alignment = Alignment(wrap_text=True, vertical="top")

    for r in results:
        ws.cell(row=r.row, column=col, value=r.code_full)
        jc = ws.cell(row=r.row, column=col + 1, value=r.justification)
        jc.alignment = Alignment(wrap_text=True, vertical="top")
        cc = ws.cell(row=r.row, column=col + 2, value=r.confidence)
        cc.fill = PatternFill("solid", fgColor=FILLS[r.confidence])
        cc.alignment = Alignment(horizontal="center", vertical="top")
        rc = ws.cell(row=r.row, column=col + 3, value=r.raise_conf or None)
        rc.alignment = Alignment(wrap_text=True, vertical="top")
        if r.no_images:
            jc.font = Font(bold=True, color="C00000")
        elif r.discrepancy:
            jc.font = Font(color="9C5700")

    ws.column_dimensions[get_column_letter(col)].width = 28
    ws.column_dimensions[get_column_letter(col + 1)].width = 80
    ws.column_dimensions[get_column_letter(col + 3)].width = 60
    ws.column_dimensions[get_column_letter(col + 2)].width = 14
    ws.freeze_panes = ws.cell(row=2, column=1)
    ws.auto_filter.ref = ws.dimensions

    _summary(wb, results, file_label, ref_has_map, override_note)
    wb.save(out_path)


def _summary(wb, results, file_label, ref_has_map, override_note=""):
    if "Validation Summary" in wb.sheetnames:
        del wb["Validation Summary"]
    s = wb.create_sheet("Validation Summary", 0 if False else len(wb.sheetnames))
    n = len(results)
    conf = Counter(r.confidence for r in results)
    lines = [
        ("File", file_label),
        ("Rows validated", n),
        ("Rows with a recommended code", n),
        ("Coverage", "100%" if n else "n/a"),
        ("", ""),
        ("Confidence High", conf.get("High", 0)),
        ("Confidence Medium", conf.get("Medium", 0)),
        ("Confidence Low", conf.get("Low", 0)),
        ("", ""),
        ("Recommended code differs from current", sum(r.changed for r in results)),
        ("Recommended code confirms current", sum(not r.changed for r in results)),
        ("No images (item will be returned)", sum(r.no_images for r in results)),
        ("Discrepancy Vertex vs TaxLookup", sum(r.discrepancy for r in results)),
        ("Rows where TaxLookup could be applied", sum(r.taxlookup_applied for r in results)),
        ("Rows decided by an override", sum(bool(r.override_id) for r in results)),
        ("Overrides", override_note or "n/a"),
        ("", ""),
    ]
    if not ref_has_map:
        lines.append(("NOTE", "TaxLookup is keyed by CMIM text path but items carry numeric CMIM codes. "
                              "Add reference/cmim_map.csv (cmim_code, cmim_path) to enable it. Until then the "
                              "recommendation is based on Vertex only."))
    lines += [("", ""), ("Confidence meaning", "High: unambiguous Vertex rule with complete data (and TaxLookup agrees when applicable). "
                                               "Medium: rule based on title/category keywords or boundary values. "
                                               "Low: missing data, ambiguity, or discrepancy with TaxLookup."),
              ("", ""), ("Top rules used", "")]
    for rule, cnt in Counter(r.rule for r in results).most_common(15):
        lines.append((f"  {rule}", cnt))
    for i, (a, b) in enumerate(lines, start=1):
        s.cell(row=i, column=1, value=a).font = Font(bold=True)
        c = s.cell(row=i, column=2, value=b)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    s.column_dimensions["A"].width = 42
    s.column_dimensions["B"].width = 100
