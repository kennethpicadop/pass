"""Motor: combina reglas Vertex, TaxLookup, imagenes y el codigo actual del item."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .reference import Reference, code_number, norm_code
from .rules import Item, Verdict, classify
from .overrides import OverrideSet

IMG_FIELDS = ("IMG_0", "IMG_1", "IMG_A", "IMG_M", "IMG_LS")
LEVELS = ["Low", "Medium", "High"]


@dataclass
class Result:
    row: int
    code_full: str
    justification: str
    confidence: str
    changed: bool
    no_images: bool
    discrepancy: bool
    rule: str
    notes: list = field(default_factory=list)
    taxlookup_applied: bool = False
    override_id: str = ""


def has_images(d: dict) -> bool:
    for f in IMG_FIELDS:
        v = d.get(f)
        if v is not None and str(v).strip() not in ("", "N/A", "n/a"):
            return True
    return False


def norm_cmim(v):
    """Devuelve (cmim_normalizado, nota). Repone el cero inicial perdido por Excel."""
    if v is None or str(v).strip() == "":
        return None, None
    s = str(v).strip()
    if ">" in s:
        return norm_code(s), None
    digits = re.sub(r"\D", "", s)
    if len(digits) == 10:
        return digits.zfill(11), "CMIM had 10 digits (leading zero lost); read as 11."
    return digits, None


def _shift(conf: str, step: int) -> str:
    return LEVELS[max(0, min(2, LEVELS.index(conf) + step))]


def validate_row(d: dict, ref: Reference, ov: OverrideSet | None = None) -> Result:
    it = Item(d)
    v: Verdict = classify(it)
    override_id = ""
    if ov is not None:
        o = ov.apply(it, v)
        if o:
            base = ref.full(v.code)
            v = Verdict(o.then_code, f"Override {o.id}: {o.reason} (base rule would give {base}).", o.conf, "override:" + o.id)
            override_id = o.id
    notes = []
    code_full = ref.full(v.code)
    conf = v.conf

    # codigo actual
    cur = it.current
    cur_num = code_number(cur) if cur else ""
    if not cur:
        lead = "No current code. "
    elif not ref.is_valid(cur):
        lead = f"Current code '{cur}' is not a valid Vertex class. "
    elif cur_num == v.code:
        lead = "Confirms current code. "
    else:
        lead = f"Change from {norm_code(cur)}. "
    changed = bool(cur) and cur_num != v.code

    # TaxLookup
    cmim, cmim_note = norm_cmim(d.get("CMIM"))
    if cmim_note:
        notes.append(cmim_note)
    path, codes = ref.lookup_for_cmim(cmim) if cmim else (None, None)
    applied = codes is not None
    discrepancy = False
    tl_txt = ""
    if applied:
        codes_n = {code_number(c) for c in codes}
        if v.code in codes_n:
            conf = _shift(conf, +1)
            tl_txt = " TaxLookup agrees."
        else:
            discrepancy = True
            conf = "Low"
            tl_txt = (" DISCREPANCY Vertex vs TaxLookup: TaxLookup suggests "
                      + " / ".join(sorted(norm_code(c) for c in codes)) + "; Vertex rule kept.")

    # imagenes
    no_img = not has_images(d)
    prefix = "NO IMAGES - item will be returned. " if no_img else ""

    just = prefix + lead + v.why + tl_txt
    if cmim_note:
        just += " " + cmim_note
    if not cmim and not applied:
        just += " (CMIM blank.)"
    return Result(d["__row__"], code_full, just.strip(), conf, changed, no_img, discrepancy, v.rule, notes, applied, override_id)


def validate_rows(rows: list[dict], ref: Reference, ov: OverrideSet | None = None) -> list[Result]:
    return [validate_row(r, ref, ov) for r in rows]
