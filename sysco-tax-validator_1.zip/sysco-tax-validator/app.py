"""Interfaz web local.  Abrir con:  python -m streamlit run app.py"""
import copy
import os
import sys
import warnings
from collections import Counter

import pandas as pd
import streamlit as st

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from taxvalidator.overrides import OverridesInvalid, load_overrides  # noqa: E402
from taxvalidator.pipeline import build_workbook_bytes, run_bytes  # noqa: E402
from taxvalidator.reference import load_reference  # noqa: E402

# --------------------------------------------------------------------------- paleta (un solo lugar para ajustarla)
BLUE, NAVY, GREEN = "#0B5CAD", "#0A2E57", "#6DB33F"
INK, MUTED, LINE, SURFACE = "#14233B", "#5B6B82", "#DCE4EE", "#FFFFFF"
C_HIGH, C_MED, C_LOW = "#2E9E5B", "#E0A100", "#D64545"
ICON = {"High": "🟢 High", "Medium": "🟡 Medium", "Low": "🔴 Low"}

st.set_page_config(page_title="Tax Classification Review", page_icon=None, layout="wide")

st.markdown(f"""
<style>
html, body, [class*="css"] {{ font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; }}
.block-container {{ padding-top: 1.2rem; max-width: 1400px; }}
header[data-testid="stHeader"] {{ background: transparent; }}
.stDeployButton, [data-testid="stToolbar"] {{ display: none !important; }}
.hero {{ background: linear-gradient(100deg, {NAVY} 0%, {BLUE} 100%); color: #fff; border-radius: 14px;
        padding: 26px 32px 22px; position: relative; overflow: hidden; margin-bottom: 18px; }}
.hero:after {{ content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 5px;
              background: linear-gradient(90deg, {GREEN}, {GREEN} 28%, transparent 28%); }}
.hero h1 {{ font-size: 1.85rem; margin: 0 0 4px; font-weight: 700; letter-spacing: -0.01em; color: #fff; }}
.hero p {{ margin: 0; opacity: .86; font-size: .98rem; }}
.hero .tag {{ display:inline-block; font-size:.72rem; letter-spacing:.09em; text-transform:uppercase;
              background: rgba(255,255,255,.14); padding: 3px 9px; border-radius: 99px; margin-bottom: 10px; }}
.kpi {{ background: {SURFACE}; border: 1px solid {LINE}; border-left: 4px solid {BLUE}; border-radius: 10px;
        padding: 12px 16px; height: 100%; }}
.kpi .v {{ font-size: 1.75rem; font-weight: 700; color: {INK}; line-height: 1.15; }}
.kpi .l {{ font-size: .78rem; color: {MUTED}; text-transform: uppercase; letter-spacing: .06em; }}
.kpi.g {{ border-left-color: {C_HIGH}; }} .kpi.y {{ border-left-color: {C_MED}; }}
.kpi.r {{ border-left-color: {C_LOW}; }} .kpi.n {{ border-left-color: {GREEN}; }}
.bar {{ display:flex; height: 12px; border-radius: 99px; overflow: hidden; background: {LINE}; margin: 6px 0 4px; }}
.legend {{ font-size: .8rem; color: {MUTED}; display:flex; gap: 18px; margin-bottom: 8px; }}
.dot {{ display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; }}
.panel {{ background: {SURFACE}; border: 1px solid {LINE}; border-radius: 12px; padding: 16px 18px; }}
.sec {{ font-size: .8rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: {BLUE};
        margin: 18px 0 6px; }}
section[data-testid="stSidebar"] {{ background: {NAVY}; }}
section[data-testid="stSidebar"] * {{ color: #E8EEF7 !important; }}
section[data-testid="stSidebar"] .stat {{ border-left: 3px solid {GREEN}; padding: 4px 0 4px 10px; margin: 10px 0; }}
section[data-testid="stSidebar"] .stat b {{ font-size: 1.25rem; display:block; color:#fff !important; }}
section[data-testid="stSidebar"] .stat span {{ font-size:.75rem; opacity:.75; text-transform:uppercase; letter-spacing:.06em; }}
.stButton > button[kind="primary"], .stDownloadButton > button {{ background: {BLUE}; color:#fff; border:0; border-radius: 8px;
        padding: .55rem 1.2rem; font-weight: 600; }}
.stButton > button[kind="primary"]:hover, .stDownloadButton > button:hover {{ background: {NAVY}; color:#fff; }}
.stTabs [data-baseweb="tab"] {{ font-weight: 600; }}
.stTabs [aria-selected="true"] {{ color: {BLUE}; }}
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------------------------------- referencias (cargadas una vez)
@st.cache_resource(show_spinner=False)
def _load():
    ref = load_reference(os.path.join(HERE, "reference"))
    ov = load_overrides(os.path.join(HERE, "reference"))
    return ref, ov


try:
    REF, OV = _load()
except OverridesInvalid as e:
    st.error(f"No se puede iniciar: {e}")
    st.stop()
bad = [o.id for o in OV.items if not REF.is_valid(o.then_code)]
if bad:
    st.error("El paquete de overrides referencia un codigo que no existe en Vertex. Contacta al administrador.")
    st.stop()

with st.sidebar:
    st.markdown("### Reference data")
    st.markdown(f'<div class="stat"><b>{len(REF.vertex_codes)}</b><span>Vertex product groups</span></div>', unsafe_allow_html=True)
    st.markdown(f'<div class="stat"><b>{len(REF.taxlookup_cmim)}</b><span>TaxLookup CMIM paths</span></div>', unsafe_allow_html=True)
    tl = "CMIM map loaded" if REF.has_cmim_map else "CMIM map pending"
    st.markdown(f'<div class="stat"><b>{tl}</b><span>TaxLookup coverage</span></div>', unsafe_allow_html=True)
    ovs = "Verified" if OV.loaded else "Not installed"
    st.markdown(f'<div class="stat"><b>{ovs}</b><span>Admin rule package</span></div>', unsafe_allow_html=True)
    st.markdown("---")
    st.caption("Decision order: blockers (images, invalid code) → what the item is (Vertex) → TaxLookup check → "
               "discrepancies flagged → missing data lowers confidence.")

st.markdown("""
<div class="hero">
  <div class="tag">Item onboarding · Tax</div>
  <h1>Tax Classification Review</h1>
  <p>Upload a Food or Beverage workbook. Every row gets a recommended Vertex code, a short justification and a confidence level.</p>
</div>
""", unsafe_allow_html=True)

# --------------------------------------------------------------------------- carga
st.markdown('<div class="sec">1 · Upload</div>', unsafe_allow_html=True)
files = st.file_uploader("Excel workbooks (.xlsx, .xlsm)", type=["xlsx", "xlsm"], accept_multiple_files=True,
                         label_visibility="collapsed")
if "runs" not in st.session_state:
    st.session_state.runs = {}
    st.session_state.edits = {}
    st.session_state.out = {}

c1, c2 = st.columns([1, 5])
go = c1.button("Validate files", type="primary", disabled=not files)
if go:
    st.session_state.runs, st.session_state.edits, st.session_state.out = {}, {}, {}
    prog = st.progress(0.0, text="Validating…")
    for i, f in enumerate(files):
        try:
            st.session_state.runs[f.name] = run_bytes(f.name, f.getvalue(), REF, OV)
        except Exception as e:  # noqa: BLE001
            st.error(f"{f.name}: {e}")
        prog.progress((i + 1) / len(files), text=f"Validated {f.name}")
    prog.empty()

if not st.session_state.runs:
    st.info("Upload one or more files and press **Validate files**. Nothing leaves this computer.")
    st.stop()


# --------------------------------------------------------------------------- resultados
def kpi(label, value, cls=""):
    return f'<div class="kpi {cls}"><div class="v">{value}</div><div class="l">{label}</div></div>'


def row_df(entry, edits):
    rows = []
    for d, r in zip(entry["rows"], entry["results"]):
        e = edits.get(r.row, {})
        rows.append({
            "Row": r.row,
            "Approved": bool(e.get("approved", False)),
            "Title": str(d.get("TITLE") or ""),
            "Current": str(d.get("PRODUCTTAXCLASS") or "").strip(),
            "Recommended": r.code_full,
            "Confidence": ICON[r.confidence],
            "Reviewer code": e.get("code", ""),
            "Flags": " · ".join(x for x in (["NO IMAGES"] if r.no_images else []) +
                                (["DISCREPANCY"] if r.discrepancy else []) +
                                (["OVERRIDE"] if r.override_id else []) if x),
            "Justification": r.justification,
            "SKU": str(d.get("SHOP_SKU") or ""),
            "Category": str(d.get("CATEGORY") or "").replace("syy_cust_tax_", ""),
        })
    return pd.DataFrame(rows)


names = list(st.session_state.runs)
tabs = st.tabs([f"{n}" for n in names])
code_options = [""] + sorted(REF.vertex_codes.values(), key=lambda s: (len(s.split(":")[0]) > 1 and not s[0].isdigit(), s))

for tab, name in zip(tabs, names):
    entry = st.session_state.runs[name]
    res = entry["results"]
    edits = st.session_state.edits.setdefault(name, {})
    n = len(res)
    conf = Counter(r.confidence for r in res)
    with tab:
        st.markdown(f'<div class="sec">2 · Summary · {entry["kind"]} file</div>', unsafe_allow_html=True)
        cols = st.columns(6)
        vals = [("Rows", n, ""), ("High confidence", conf["High"], "g"), ("Medium", conf["Medium"], "y"),
                ("Low", conf["Low"], "r"), ("Code changes", sum(r.changed for r in res), "n"),
                ("No images", sum(r.no_images for r in res), "r")]
        for col, (l, v, cls) in zip(cols, vals):
            col.markdown(kpi(l, f"{v:,}", cls), unsafe_allow_html=True)
        hp, mp, lp = (100 * conf[k] / n if n else 0 for k in ("High", "Medium", "Low"))
        st.markdown(
            f'<div class="bar"><div style="width:{hp}%;background:{C_HIGH}"></div><div style="width:{mp}%;background:{C_MED}"></div>'
            f'<div style="width:{lp}%;background:{C_LOW}"></div></div>'
            f'<div class="legend"><span><i class="dot" style="background:{C_HIGH}"></i>High {hp:.0f}%</span>'
            f'<span><i class="dot" style="background:{C_MED}"></i>Medium {mp:.0f}%</span>'
            f'<span><i class="dot" style="background:{C_LOW}"></i>Low {lp:.0f}%</span>'
            f'<span>Discrepancies: {sum(r.discrepancy for r in res)}</span></div>', unsafe_allow_html=True)

        st.markdown('<div class="sec">3 · Review queue</div>', unsafe_allow_html=True)
        df = row_df(entry, edits)
        f1, f2, f3, f4 = st.columns([2, 2, 2, 3])
        sel_conf = f1.multiselect("Confidence", ["High", "Medium", "Low"], default=["Medium", "Low"], key=f"cf{name}")
        only_chg = f2.checkbox("Only code changes", value=False, key=f"ch{name}")
        flags = f3.multiselect("Flags", ["NO IMAGES", "DISCREPANCY", "OVERRIDE"], key=f"fl{name}")
        q = f4.text_input("Search title / SKU / category", key=f"q{name}", placeholder="e.g. juice, 0053202…")
        view = df[df["Confidence"].str.contains("|".join(sel_conf) if sel_conf else "^$")]
        if only_chg:
            view = view[view["Current"].str.strip() != view["Recommended"].str.strip()]
        for fl in flags:
            view = view[view["Flags"].str.contains(fl)]
        if q:
            ql = q.lower()
            view = view[view.apply(lambda r: ql in (r["Title"] + r["SKU"] + r["Category"]).lower(), axis=1)]
        st.caption(f"{len(view):,} of {n:,} rows shown. Tick **Approved** or pick a **Reviewer code** to record your decision; "
                   "your decision is what is written to the final workbook.")
        edited = st.data_editor(
            view, hide_index=True, use_container_width=True, height=470, key=f"ed{name}",
            disabled=[c for c in view.columns if c not in ("Approved", "Reviewer code")],
            column_config={
                "Row": st.column_config.NumberColumn(width=52),
                "Approved": st.column_config.CheckboxColumn("OK", width=48),
                "Title": st.column_config.TextColumn(width=250),
                "Current": st.column_config.TextColumn(width=150),
                "Recommended": st.column_config.TextColumn(width=165),
                "Confidence": st.column_config.TextColumn(width=100),
                "Reviewer code": st.column_config.SelectboxColumn("Your code", options=code_options, width=150),
                "Flags": st.column_config.TextColumn(width=130),
                "Justification": st.column_config.TextColumn(width=420),
                "SKU": st.column_config.TextColumn(width=130),
                "Category": st.column_config.TextColumn(width=110),
            })
        for _, r in edited.iterrows():
            edits[int(r["Row"])] = {"approved": bool(r["Approved"]), "code": r["Reviewer code"] or ""}

        if len(view):
            opts = {f"Row {int(r.Row)} · {r.Title[:70]}": int(r.Row) for r in view.itertuples()}
            pick = st.selectbox("Inspect a row", list(opts), key=f"pk{name}")
            rr = next(x for x in res if x.row == opts[pick])
            colr = {"High": C_HIGH, "Medium": C_MED, "Low": C_LOW}[rr.confidence]
            st.markdown(
                f'<div class="panel" style="border-left:4px solid {colr}"><b>{rr.code_full}</b> &nbsp;·&nbsp; '
                f'<span style="color:{colr};font-weight:700">{rr.confidence} confidence</span><br>'
                f'<span style="color:{MUTED}">{rr.justification}</span></div>', unsafe_allow_html=True)

        st.markdown('<div class="sec">4 · Export</div>', unsafe_allow_html=True)
        nrev = sum(1 for e in edits.values() if e.get("code"))
        napp = sum(1 for e in edits.values() if e.get("approved"))
        st.write(f"**{napp}** approved · **{nrev}** with a manual reviewer code")
        if st.button("Generate reviewed workbook", type="primary", key=f"gen{name}"):
            final = copy.deepcopy(res)
            for r in final:
                e = edits.get(r.row)
                if e and e.get("code"):
                    r.justification = f"Reviewer set {e['code']} (recommendation was {r.code_full}). " + r.justification
                    r.code_full, r.confidence = e["code"], "High"
            with st.spinner("Building workbook…"):
                st.session_state.out[name] = build_workbook_bytes(entry, final, REF, OV)
        if name in st.session_state.out:
            base = os.path.splitext(name)[0]
            st.download_button("Download reviewed workbook", st.session_state.out[name],
                               file_name=f"{base}_VALIDATED.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               key=f"dl{name}")
