@echo off
REM Arrastra uno o varios .xlsx encima de este archivo para validarlos.
REM Genera <nombre>_VALIDATED.xlsx en la misma carpeta del archivo.
if "%~1"=="" (
  echo Arrastra un archivo .xlsx encima de este .bat
  pause
  exit /b
)
python -m pip install -q -r "%~dp0requirements.txt"
python "%~dp0validate.py" %*
echo.
pause
