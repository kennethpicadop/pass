"""Lectura robusta de Excel.

Los archivos guardados como "Strict Open XML" (como los de Food/Beverage) no los
abre openpyxl: Beverage aparece con 0 hojas y sin error. Aqui los normalizamos a
Transitional en memoria antes de cargarlos.
"""
from __future__ import annotations

import io
import re
import zipfile

import openpyxl

_REPLACEMENTS = [
    ("http://purl.oclc.org/ooxml/spreadsheetml/main",
     "http://schemas.openxmlformats.org/spreadsheetml/2006/main"),
    ("http://purl.oclc.org/ooxml/officeDocument/relationships",
     "http://schemas.openxmlformats.org/officeDocument/2006/relationships"),
    ("http://purl.oclc.org/ooxml/drawingml/main",
     "http://schemas.openxmlformats.org/drawingml/2006/main"),
    ("http://purl.oclc.org/ooxml/officeDocument/sharedTypes",
     "http://schemas.openxmlformats.org/officeDocument/2006/sharedTypes"),
    ("http://purl.oclc.org/ooxml/officeDocument/extendedProperties",
     "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"),
    ("http://purl.oclc.org/ooxml/officeDocument/docPropsVTypes",
     "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"),
]
_XML_LIKE = (".xml", ".rels")


def _is_strict(zf: zipfile.ZipFile) -> bool:
    try:
        head = zf.read("xl/workbook.xml")[:4000].decode("utf-8", "ignore")
    except KeyError:
        return False
    return "purl.oclc.org/ooxml" in head or 'conformance="strict"' in head


def _to_transitional(path: str) -> io.BytesIO:
    out = io.BytesIO()
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith(_XML_LIKE) or item.filename == "[Content_Types].xml":
                text = data.decode("utf-8")
                for old, new in _REPLACEMENTS:
                    text = text.replace(old, new)
                text = text.replace(' conformance="strict"', "")
                # Las rutas de relaciones strict usan tipos con el mismo prefijo ya reemplazado.
                data = text.encode("utf-8")
            zout.writestr(item, data)
    out.seek(0)
    return out


def load_workbook_any(path: str) -> openpyxl.Workbook:
    """Abre un .xlsx normal o Strict y devuelve un Workbook de openpyxl."""
    with zipfile.ZipFile(path) as zf:
        strict = _is_strict(zf)
    src = _to_transitional(path) if strict else path
    wb = openpyxl.load_workbook(src)  # formulas intactas; solo leemos valores de texto
    if not wb.worksheets:
        raise ValueError("El archivo no tiene hojas legibles: " + path)
    return wb


def read_sheet(ws) -> tuple[list[str], list[dict]]:
    """Devuelve (encabezados, filas) de la hoja; fila 1 = encabezados."""
    rows = ws.iter_rows(values_only=True)
    headers = [("" if h is None else str(h).strip()) for h in next(rows)]
    data = []
    for i, r in enumerate(rows, start=2):
        if r is None or all(v is None or str(v).strip() == "" for v in r):
            continue
        d = {h: v for h, v in zip(headers, r) if h}
        d["__row__"] = i
        data.append(d)
    return headers, data
