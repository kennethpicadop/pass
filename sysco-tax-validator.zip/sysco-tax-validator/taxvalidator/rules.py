"""Reglas de clasificacion basadas en las definiciones de Vertex.

Orden = jerarquia (la primera regla que aplica gana):
  1. Items que NO son comida (medico, suplementos, desechables, suministros)
  2. Bebidas (bar mix, polvos, jarabes, te/cafe, agua, jugo)
  3. Comida (colorante, cacao, dulces, helado, snacks, condimentos, comida general)

Cada regla devuelve un Verdict con el codigo recomendado, el motivo corto, la fuente
(definicion de Vertex) y una confianza propia (High / Medium / Low).
Las palabras clave estan en listas al inicio para poder ajustarlas facilmente.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class Verdict:
    code: str            # numero de clase Vertex, ej. "56"
    why: str             # justificacion corta
    conf: str            # High | Medium | Low
    rule: str = ""       # id de la regla (para depurar)


# ----------------------------------------------------------------------------- utilidades
def _rx(words):
    return re.compile(r"(?<![A-Z0-9])(?:" + "|".join(words) + r")(?:S|ES)?(?![A-Z0-9])")


def has(text: str, words) -> bool:
    return bool(_rx(words).search(text))


_UOM_OZ = {"OZ": 1.0, "OUNCE": 1.0, "US OUNCE": 1.0, "LB": 16.0, "US POUND": 16.0, "POUND": 16.0,
           "G": 0.035274, "GRAM": 0.035274, "KG": 35.274, "FOZ": 1.0, "FO": 1.0, "FLUID OUNCE US": 1.0,
           "ML": 0.033814, "L": 33.814, "GAL": 128.0}


def unit_oz(size, uom):
    """Tamano de una unidad en onzas (aprox.). None si no es peso/volumen."""
    try:
        s = float(str(size).replace(",", ""))
    except (TypeError, ValueError):
        return None
    f = _UOM_OZ.get(str(uom or "").strip().upper())
    return s * f if f else None


def num(v):
    try:
        return float(str(v).replace(",", "").replace("%", ""))
    except (TypeError, ValueError):
        return None


# ----------------------------------------------------------------------------- palabras clave
KW_SUPPLEMENT = ["SUPPLEMENT", "VITAMIN", "CAPSULE", "SOFTGEL", "PROBIOTIC",
                 "COLLAGEN", "CREATINE", "PRE WORKOUT", "PRE-WORKOUT", "MULTIVITAMIN", "MELATONIN",
                 "TABLET"]
KW_MEDICAL_WOUND = ["BANDAGE", "GAUZE", "WOUND", "BAND-AID", "BAND AID", "ADHESIVE STRIP"]
KW_MEDICAL_OTC = ["ACETAMINOPHEN", "IBUPROFEN", "ASPIRIN", "ANTACID", "ANTIHISTAMINE", "DRUG FACTS", "PAIN RELIEVER"]
KW_FEMININE = ["TAMPON", "FEMININE", "SANITARY PAD", "SANITARY NAPKIN", "PANTILINER"]
KW_DIAPER = ["DIAPER", "DIAPERS"]
KW_GLOVE = ["GLOVE"]
KW_CUTLERY = ["FORK", "SPOON", "KNIFE", "CUTLERY", "STRAW", "STIRRER", "CHOPSTICK", "SPORK", "UTENSIL", "PICK", "SKEWER"]
KW_TOGO = ["CUP", "LID", "CONTAINER", "CLAMSHELL", "TRAY", "PLATE", "BOWL", "PLATTER", "TO-GO", "TO GO", "BAGASSE",
           "CAKE CIRCLE", "FOOD TRAY", "BOAT", "CARTON", "WRAP", "PAN LINER"]
KW_NAPKIN = ["NAPKIN"]
KW_TISSUE = ["TOILET TISSUE", "TOILET PAPER", "FACIAL TISSUE"]
KW_TABLECOVER = ["TABLECLOTH", "TABLE COVER", "TABLE SKIRT", "BUTCHER PAPER"]
KW_TRASH = ["TRASH", "LINER", "GARBAGE", "WASTE BAG", "BIN LINER"]

KW_BARMIX = ["COCKTAIL MIX", "COCKTAIL MIXER", "COCKTAIL", "MIXER", "MARGARITA", "DAIQUIRI", "MOJITO", "BLOODY MARY",
             "SOUR MIX", "SWEET SOUR", "BAR MIX", "BITTERS", "OLD FASHIONED", "COLADA", "MIMOSA", "MARTINI", "COSMOPOLITAN", "LEMON DROP", "MOSCOW MULE", "SPRITZ", "MANHATTAN", "NEGRONI", "BARMIXXERS"]
KW_GARNISH = ["GARNISH", "RIMMER", "RIMMING", "OLIVE", "DEHYDRATED", "COCKTAIL ONION", "MARASCHINO", "CHERRIES"]
KW_MOCKTAIL = ["MOCKTAIL", "NON ALCOHOLIC WINE", "NONALCOHOLIC WINE", "NON-ALCOHOLIC WINE", "ALCOHOL FREE WINE"]
KW_POWDER = ["POWDER", "DRINK MIX", "ATOLE", "ELECTROLYTE", "HYDRATION", "INSTANT", "STICK PACK", "MIX POWDER", "CRYSTALS"]
KW_SYRUP = ["SYRUP", "CONCENTRATE", "SIMPLE SYRUP", "PUREE", "LIQUID FLAVOR"]
KW_TEA_LOOSE = ["BAG", "LEAF", "LEAVES", "LOOSE", "K-CUP", "PODS", "POD", "BREW OVER ICE", "SACHET"]
KW_COFFEE_LOOSE = ["WHOLE BEAN", "BEANS", "GROUND", "K-CUP", "PODS", "POD", "ROAST", "DECAF", "INSTANT"]
KW_MILK = ["MILK", "LATTE", "CREAM", "CREAMER", "CAPPUCCINO", "MOCHA", "CHAI LATTE", "OAT", "ALMOND"]
KW_CARB = ["SODA", "SPARKLING", "CARBONATED", "SELTZER", "TONIC", "COLA", "GINGER ALE", "BUBBLY", "FIZZ"]
KW_FLAVOR = ["FLAVOR", "FLAVORED", "LEMON", "LIME", "BERRY", "BLACKBERRY", "STRAWBERRY", "RASPBERRY", "ORANGE", "MANGO",
             "PEACH", "LIMON", "CUCUMBER", "GRAPEFRUIT", "WATERMELON", "LEMONADE", "COCONUT", "CHERRY", "PINEAPPLE", "APPLE",
             "GRAPE", "MINT", "GUAVA", "PASSION"]
KW_VEG_JUICE = ["VEGETABLE", "TOMATO", "CARROT", "BEET", "CELERY", "GREEN JUICE", "KALE"]

KW_COLORING = ["FOOD COLOR", "FOOD COLORING", "FOOD DYE", "ICING COLOR"]
KW_COCOA = ["COCOA POWDER", "COCOA"]
KW_MARSH = ["MARSHMALLOW", "MARSHMALLOWS"]
KW_MINTS = ["MINT", "MINTS", "BREATH MINT"]
KW_BAKE_CANDY = ["BAKING CHIP", "CHOCOLATE CHIP", "BAKING BAR", "BAKING MELT", "BAKING CHOCOLATE", "BAKING WAFER", "MORSEL", "CANDY MELT"]
KW_CANDY_FLOUR = ["WAFER", "COOKIE", "BISCUIT", "PRETZEL", "BROWNIE", "CAKE", "CRISP", "GRAHAM"]
KW_ICECREAM = ["ICE CREAM", "GELATO", "SORBET", "POPSICLE", "NOVELTY", "FROZEN DESSERT", "FROZEN YOGURT"]
KW_SNACK = ["CHIP", "COOKIE", "CRACKER", "PRETZEL", "POPCORN", "SNACK MIX", "TRAIL MIX", "GRANOLA BAR", "SNACK BAR",
            "ENERGY BAR", "PROTEIN BAR", "DRIED FRUIT", "CRISP", "PUFF", "RICE CAKE"]
KW_NOT_SNACK = ["BATTER", "BREADING", "FLOUR", "JERKY", "DOUGH", "FISH", "CHICKEN", "BEEF", "PORK", "SEASONING", "MIX FISH"]
KW_DOUGH = ["DOUGH", "BATTER", "MIX"]
KW_NUT_PROCESSED = ["SLICED", "SLIVERED", "CHOPPED", "DICED", "PIECES", "MEAL", "FLOUR", "PASTE", "BUTTER",
                    "SUGAR COATED", "CANDIED", "COATED", "IN SHELL"]
KW_CONDIMENT = ["KETCHUP", "MUSTARD", "MAYONNAISE", "MAYO", "HOT SAUCE", "RELISH", "JELLY", "JAM", "SYRUP PACKET"]
KW_PORTION = ["PACKET", "PORTION", "SINGLE SERVE", "SINGLE-SERVE", "SACHET", "PC ", "INDIVIDUAL", "PORTION CUP", "POUCH"]

CAT_BEVERAGE = ("juice", "sportsdrinks", "readytodrink", "water", "tea", "coffee", "beerandwine", "cocktailmixes")
CAT_BEVERAGE_MAYBE = ("canneddry", "cocoa", "syrup", "syrups", "wine")   # solo si el titulo suena a bebida
KW_DRINK_WORDS = ["DRINK", "BEVERAGE", "JUICE", "SODA", "WATER", "TEA", "COFFEE", "LEMONADE", "KOMBUCHA", "NECTAR",
                  "SMOOTHIE", "SHAKE", "COCKTAIL", "MIXER", "TONIC", "COLD BREW", "ESPRESSO", "HOT CHOCOLATE", "COCOA MIX"]
KW_BEV_SYRUP = ["COFFEE", "LATTE", "BEVERAGE", "COCKTAIL", "DRINK", "ITALIAN SODA", "SIMPLE", "INFUSED", "MONIN",
                "TORANI", "BOBA", "SODA", "LEMONADE", "TEA"]
KW_FOOD_SYRUP = ["PANCAKE", "MAPLE", "WAFFLE", "CHOCOLATE", "CARAMEL", "AGAVE", "HONEY", "TOPPING", "FUDGE", "DESSERT",
                 "MOLASSES", "CORN SYRUP", "SAUCE"]
CAT_FOODISH_DEFAULT = ("bakery", "baking", "bean", "berries", "boxedmeat", "bread", "breakfast", "candy", "canned", "cereal",
                       "cheese", "chili", "chips", "chocolate", "citrus", "coconut", "cocktail", "condiment", "cookies",
                       "crackers", "dressing", "fish", "flour", "fruit", "gravies", "ketchup", "mayonnaise", "milk",
                       "mustard", "nuts", "oils", "olives", "pancake", "pasta", "peppers", "pickle", "popcorn", "salad",
                       "salsa", "sauce", "seasoning", "sheetdough", "snack", "soup", "spice", "spreads", "sugar",
                       "syrup", "tuna", "vegetable", "vinegar", "wine", "bases", "hotcereal", "coldcereal")


# ----------------------------------------------------------------------------- fila
class Item:
    """Vista normalizada de una fila del Excel."""

    def __init__(self, d: dict):
        g = lambda k: ("" if d.get(k) is None else str(d.get(k)).strip())
        self.d = d
        self.cat = g("CATEGORY").lower().replace("syy_cust_tax_", "")
        self.title = g("TITLE").upper()
        self.text = " ".join(g(k) for k in ("TITLE", "product_descriptor", "marketing_statements",
                                           "additional_product_information", "quality_and_format")).upper()
        self.size = g("SIZE")
        self.uom = g("SIZE_UOM")
        self.oz = unit_oz(self.size, self.uom)
        self.carb = g("BEV-CARBONATION")
        self.conc = g("BEV-CONCENTRATE")
        self.juice = num(g("BEV-JUICEPCT"))
        self.sugar = num(g("SUGARCONTENT"))
        self.container = g("CONTAINERTYPE")
        self.current = g("PRODUCTTAXCLASS")

    @property
    def is_beverage(self) -> bool:
        if has(self.title, KW_SUPPLEMENT):
            return False
        if any(self.cat.startswith(c) for c in CAT_BEVERAGE):
            return True
        if any(self.cat.startswith(c) for c in CAT_BEVERAGE_MAYBE):
            return bool(self.carb) or has(self.title, KW_DRINK_WORDS) or has(self.title, KW_BARMIX) or (
                has(self.title, KW_BEV_SYRUP) and not has(self.title, KW_FOOD_SYRUP))
        if has(self.title, ["HYDRATION", "ELECTROLYTE"]):
            return True
        return bool(self.carb) and has(self.title, KW_DRINK_WORDS)


# ----------------------------------------------------------------------------- reglas: no comida
def r_nonfood(it: Item):
    t, c = it.title, it.cat

    if has(t, KW_SUPPLEMENT) and not has(t, ["TABLETOP", "TABLE"]):
        strong = has(t, ["SUPPLEMENT", "VITAMIN", "CAPSULE", "SOFTGEL"])
        return Verdict("18", "Title indicates a dietary supplement (Vertex 18: identified by a Supplement Facts panel); "
                       "confirm the label shows Supplement Facts.", "Medium" if strong else "Low", "supplement")
    if has(t, KW_DIAPER):
        code = "97" if has(t, ["ADULT", "BRIEF"]) else "98"
        return Verdict(code, "Diaper item (Vertex 97 adult / 98 child).", "Medium", "diaper")
    if has(t, KW_FEMININE):
        return Verdict("95", "Feminine product (Vertex 95).", "High", "feminine")
    if has(t, KW_MEDICAL_WOUND) and not c.startswith(("dressing", "saladdressing")):
        return Verdict("92", "Wound-care item used directly on a person (Vertex 92).", "Medium", "wound")
    if has(t, KW_MEDICAL_OTC):
        return Verdict("90", "OTC medicine; confirm a 'Drug Facts' label (Vertex 90).", "Medium", "otc")

    if "glove" in c or has(t, KW_GLOVE):
        return Verdict("63", "Disposable glove used in food preparation (Vertex 63); use 89 if sold as safety clothing "
                       "to prevent injury.", "Medium", "glove")
    if has(t, KW_TABLECOVER):
        return Verdict("67", "Table covering (Vertex 67).", "High", "tablecover")
    if has(t, KW_TISSUE):
        return Verdict("74", "Toilet/facial tissue (Vertex 74).", "High", "tissue")
    if has(t, KW_NAPKIN) or "napkin" in c:
        return Verdict("62", "Disposable napkin: non-essential to delivery, does not directly touch food (Vertex 62).",
                       "Medium", "napkin")
    if "trash" in c or has(t, KW_TRASH):
        return Verdict("72", "Trash bag/liner: general supply never resold (Vertex 72).", "Medium", "trash")
    if ("dispenser" in c or "othersupplies" in c or "handandbodycare" in c or c.startswith("healthandpersonal")) \
            and not has(t, ["HYDRATION", "ELECTROLYTE", "DRINK MIX"]):
        return Verdict("72", "General supply (Vertex 72); no medical, supplement or hygiene keyword found.",
                       "Medium" if "dispenser" in c else "Low", "supplies-general")
    if "carryout" in c or "grocerybag" in c:
        return Verdict("62", "Carry-out/grocery bag: non-essential to delivery, no food contact (Vertex 62).", "Medium", "carryout")
    if "storagebag" in c:
        return Verdict("64", "Disposable food-storage bag (Vertex 64).", "High", "storage")
    if any(k in c for k in ("cutlery", "straws", "catering", "skewers")) or has(t, KW_CUTLERY):
        return Verdict("61", "Disposable cutlery/straw/pick: touches food but non-essential to delivery (Vertex 61).",
                       "Medium", "cutlery")
    if any(k in c for k in ("cups", "lids", "containers", "trays", "plates", "platters", "to-go", "disposables",
                            "bagasse", "moldedfiber", "beverage")) and not it.is_beverage:
        return Verdict("60", "Disposable food/drink container or serveware essential to delivery (Vertex 60).",
                       "Medium", "disposable-60")
    if it.cat.startswith(("cups", "lids")) or has(t, ["PAPERBOARD FOOD TRAY", "FOOD TRAY", "CAKE CIRCLE"]):
        return Verdict("60", "Disposable container essential to delivery (Vertex 60).", "Medium", "disposable-60")
    return None


# ----------------------------------------------------------------------------- reglas: bebidas
def _juice_class(carbonated: bool, p: float, veg: bool) -> str:
    if p >= 100:
        base = 45 if veg else 43
    elif p >= 70:
        base = 41
    elif p >= 50:
        base = 39
    elif p >= 25:
        base = 37
    elif p >= 10:
        base = 35
    else:
        base = 33
    return str(base if carbonated else base + 1)


def _is_carbonated(it: Item):
    if it.carb:
        low = it.carb.lower()
        if low.startswith("non"):
            return False
        if "carbon" in low:
            return True
    if has(it.title, KW_CARB):
        return True
    return None


def r_beverage(it: Item):
    if not it.is_beverage:
        return None
    t, c = it.title, it.cat

    # 56 / garnish / mocktail
    if has(t, KW_GARNISH) and not has(t, ["JUICE"]):
        return Verdict("10", "Edible cocktail garnish/rimmer, sold as food and not as a drink (Vertex 10).", "Medium", "garnish")
    if has(t, KW_MOCKTAIL):
        return Verdict("10", "Ready-to-drink non-alcoholic cocktail/wine analogue: no specific beverage class in Vertex; "
                       "treated as 10 (Vertex 10).", "Low", "mocktail")
    if has(t, KW_BARMIX) and not has(t, ["TEA", "JUICE", "WATER", "SODA"]) and not (
            has(t, ["COFFEE"]) and not has(t, ["MARTINI"])):
        if has(t, ["DRINK MIX"]):
            return Verdict("56", "Cocktail flavor 'drink mix': bar mixer if liquid (Vertex 56 Bar Mixes); if it is a powder "
                           "to reconstitute use 50. Need prep form to confirm.", "Low", "barmix-or-powder")
        conf = "Low" if has(t, ["BITTERS"]) else "High"
        return Verdict("56", "Cocktail/bar mixer used to prepare drinks at the bar (Vertex 56 Bar Mixes).", conf, "barmix")

    # polvos
    if (has(t, KW_POWDER) and not has(t, ["TEA", "COFFEE", "LATTE", "MATCHA", "JUICE", "SODA"])) or (
            has(t, ["POWDER", "INSTANT", "STICK PACK", "DRINK MIX"]) and has(t, ["TEA", "COFFEE", "LATTE", "COCOA", "MATCHA"])):
        if has(t, ["TEA", "COFFEE", "LATTE", "MATCHA"]):
            if has(t, ["INSTANT"]):
                return Verdict("12", "Instant coffee/tea: unprepared coffee/tea product (Vertex 12).", "Medium", "instant")
            return Verdict("51", "Powdered tea/coffee drink mix (Vertex 51); use 50 if it is a sugar-based mix instead.", "Medium", "powder-tea")
        if has(t, ["COCOA", "HOT CHOCOLATE"]):
            return Verdict("12", "Hot chocolate mix (Vertex 12 Coffee, Tea, Hot Chocolate).", "Medium", "hotchoc")
        return Verdict("50", "Powdered mix that must be prepared with water to make a drink (Vertex 50).", "High", "powder")
    # 18 / 20 en bebidas (batidos proteicos)
    if has(t, ["PROTEIN", "SHAKE", "MEAL REPLACEMENT"]) and not has(t, ["TEA", "COFFEE", "WATER", "JUICE"]):
        if "MEAL REPLACEMENT" in it.text:
            return Verdict("20", "Label text says 'Meal Replacement' (Vertex 20 requires it explicitly).", "High", "meal-repl")
        return Verdict("10", "Protein shake/drink: Vertex 20 requires the label to state 'Meal Replacement' and 18 a "
                       "Supplement Facts panel; neither is evidenced here. Need label to confirm.", "Low", "protein-shake")

    # jarabes / concentrados
    syr_cat = c.startswith(("syrup", "cocktailmixes")) or has(t, ["SYRUP"])
    if syr_cat and not has(t, KW_FOOD_SYRUP):
        return Verdict("1C", "Beverage syrup/flavor additive (Vertex 1C).", "Medium", "bev-syrup")
    if it.conc.lower() in ("syrup", "concentrated") and not has(t, ["JUICE", "TEA", "COFFEE"]):
        return Verdict("1C", "Beverage concentrate/syrup (BEV-CONCENTRATE) = flavor additive (Vertex 1C).", "Low", "bev-conc")

    # cacao
    if c.startswith("cocoa") or has(t, ["HOT CHOCOLATE", "HOT COCOA"]):
        return Verdict("12", "Cocoa/hot-chocolate beverage product (Vertex 12).", "Medium", "cocoa-bev")

    ready = (it.conc.lower() == "readytodrink") or bool(it.container) or not it.conc
    # te
    if c.startswith("tea") or (has(t, ["TEA"]) and not has(t, ["JUICE", "LEMONADE"])):
        if has(t, KW_TEA_LOOSE) and not ready:
            return Verdict("12", "Unprepared tea (bags/leaves) (Vertex 12).", "Medium", "tea-loose")
        if has(t, KW_MILK):
            return Verdict("52", "Bottled tea with milk (Vertex 52).", "Medium", "tea-milk")
        return Verdict("53", "Bottled tea without milk (Vertex 53).", "High" if ready and it.conc else "Medium", "tea")
    # cafe
    if c.startswith("coffee") or has(t, ["COFFEE", "COLD BREW", "ESPRESSO"]):
        if has(t, KW_COFFEE_LOOSE) and not it.conc.lower() == "readytodrink":
            return Verdict("12", "Unprepared coffee (beans/ground/pods) (Vertex 12).", "Medium", "coffee-loose")
        if has(t, KW_MILK) or "CREAM" in t:
            return Verdict("54", "Bottled coffee with milk (Vertex 54).", "Medium", "coffee-milk")
        return Verdict("55", "Bottled coffee without milk (Vertex 55).", "High" if it.conc else "Medium", "coffee")

    carbonated = _is_carbonated(it)
    flavored = has(t, KW_FLAVOR) or (it.sugar or 0) > 0
    juice = it.juice
    veg = has(t, KW_VEG_JUICE)
    is_water = c.startswith("water") or t.startswith("WATER") or has(t, ["SPARKLING WATER", "SELTZER", "MINERAL WATER"])

    if is_water and not has(t, ["COCONUT", "JUICE"]) and (juice is None or juice == 0):
        if carbonated is True:
            if flavored:
                return Verdict("33", "Flavored carbonated water, <10% juice (Vertex 33). Plain carbonated water would be 32.",
                               "Medium", "water-carb-flav")
            return Verdict("32", "Plain carbonated water (Vertex 32).", "High" if it.carb else "Medium", "water-carb")
        if carbonated is False and flavored and (it.sugar or 0) > 0:
            return Verdict("31", "Non-carbonated flavored, sweetened water (Vertex 31).", "Medium", "water-flav")
        if carbonated is False and flavored:
            return Verdict("31", "Non-carbonated flavored water (Vertex 31); confirm it is sweetened, else 30.", "Low", "water-flav")
        return Verdict("30", "Individually bottled pure still water (Vertex 30).",
                       "High" if carbonated is False else "Medium", "water-still")

    # jugos / bebidas por % de jugo y carbonatacion (Vertex 33-46)
    if juice is None:
        guess = "33" if carbonated else "34"
        return Verdict(guess, "Juice % not provided (BEV-JUICEPCT blank): defaulted to <10% juice band. Need label/spec to "
                       "confirm juice % and carbonation (Vertex 33-46).", "Low", "juice-missing")
    if carbonated is None:
        carbonated = False
        miss = " Carbonation not provided: assumed non-carbonated."
        conf_cap = "Low"
    else:
        miss, conf_cap = "", "High"
    code = _juice_class(carbonated, juice, veg)
    boundary = juice in (10, 25, 50, 70, 100)
    carb_txt = "carbonated" if carbonated else "non-carbonated"
    why = f"{carb_txt.capitalize()} beverage with {juice:g}% juice (BEV-JUICEPCT) -> Vertex {code}.{miss}"
    if boundary:
        why += " Value sits on a band boundary; confirm."
    conf = "Medium" if boundary and conf_cap == "High" else conf_cap
    if juice == 0 and carbonated is False and not it.carb:
        conf = "Low"
    return Verdict(code, why, conf, "juice-band")


# ----------------------------------------------------------------------------- reglas: comida
def r_food(it: Item):
    t, c = it.title, it.cat
    oz = it.oz

    if has(t, KW_COLORING):
        return Verdict("1A", "Food coloring (Vertex 1A).", "High", "coloring")
    if has(t, ["ICE CUBE", "BAGGED ICE", "PACKAGED ICE"]):
        return Verdict("1B", "Ice (Vertex 1B).", "High", "ice")
    if has(t, KW_COCOA) and not has(t, ["MIX", "HOT"]):
        return Verdict("13", "Cocoa product (Vertex 13).", "High", "cocoa")

    # dulces
    if has(t, KW_MARSH):
        return Verdict("25", "Marshmallows (Vertex 25).", "High", "marshmallow")
    if c.startswith(("candy", "chocolate", "snacksandcandy")) or has(t, ["CANDY", "GUMMY BEAR", "LOLLIPOP", "CARAMEL CHEW"]):
        if has(t, KW_BAKE_CANDY):
            return Verdict("24", "Candy used in baking, no flour, no refrigeration (Vertex 24).", "Medium", "baking-candy")
        if has(t, KW_MINTS):
            return Verdict("21", "Mints: individually wrapped candies (Vertex 21).", "Medium", "mints")
        if has(t, KW_CANDY_FLOUR):
            return Verdict("23", "Candy-type product that contains flour or needs refrigeration (Vertex 23).", "Medium", "candy-flour")
        return Verdict("22", "Candy without flour, no refrigeration (Vertex 22).", "High", "candy")

    # helados
    if has(t, KW_ICECREAM):
        if oz is not None and oz > 16:
            return Verdict("10", "Ice cream larger than a pint (Vertex 17 covers pints or smaller) -> Food (Vertex 10).", "Medium", "icecream-big")
        return Verdict("17", "Ice cream/novelty in pints or smaller (Vertex 17).", "Medium" if oz is not None else "Low", "icecream")

    # masa/prep antes que snacks
    if has(t, ["COOKIE DOUGH", "DOUGH"]) and not has(t, ["PRETZEL"]):
        return Verdict("10", "Dough is a food ingredient (Vertex 10: cookie dough listed).", "High", "dough")

    # snacks (<= 1 lb por unidad)
    snack_cat = c.startswith(("chips", "snacks", "popcorn", "cookies", "crackers", "nutsandseeds"))
    if c.startswith("nutsandseeds") and has(t, ["CARAMEL", "CHOCOLATE", "TOFFEE", "FUDGE"]) and not has(t, ["CHIP"]):
        return Verdict("22", "Chocolate/caramel confection sold under nuts category: candy without flour (Vertex 22); confirm.",
                       "Low", "nuts-candy2")
    if (snack_cat or has(t, KW_SNACK)) and not has(t, KW_NOT_SNACK):
        if c.startswith("nutsandseeds") and has(t, KW_NUT_PROCESSED):
            return Verdict("10", "Processed/ingredient nuts (sliced, meal, butter, coated or in shell) are Food (Vertex 10).",
                           "Medium", "nuts-food")
        if c.startswith("nutsandseeds") and has(t, ["SUGAR COATED", "CANDIED", "CHOCOLATE COVERED"]):
            return Verdict("22", "Candy-coated nuts are candy (Vertex 22).", "Medium", "nuts-candy")
        if oz is None:
            return Verdict("11", "Snack item (Vertex 11); unit size not readable, cannot confirm the <=1 lb (16 oz) limit.", "Low", "snack-nosize")
        if oz <= 16.01:
            return Verdict("11", f"Snack item, unit size {oz:.1f} oz <= 1 lb (Vertex 11).", "High", "snack")
        return Verdict("10", f"Snack-type item but unit size {oz:.1f} oz is over 1 lb; Vertex 11 limit is 1 lb -> Food (Vertex 10).",
                       "Medium", "snack-big")

    # condimentos
    if c.startswith(("ketchup", "mustard", "mayonnaise")) or has(t, KW_CONDIMENT):
        if has(t, KW_PORTION):
            return Verdict("15", "Individually packaged condiment (packet/cup) (Vertex 15).", "Medium", "condiment-portion")
        limit = 20 if "ketchup" in c or has(t, ["KETCHUP"]) else 12
        if oz is not None and oz <= limit and not has(t, ["JAR", "JAM", "JELLY", "RELISH"]):
            return Verdict("15", f"Condiment bottle {oz:.1f} oz <= {limit} oz (Vertex 15, specific to CO); otherwise Food (10). "
                           "Confirm applicability.", "Low", "condiment-bottle")
        return Verdict("10", "Condiment in bulk/jar size: Food (Vertex 10); Vertex 15 only covers individual packs/small bottles.",
                       "Medium", "condiment-bulk")

    # bebidas que llegaron como comida (RTD en categoria food) ya se manejan en r_beverage
    # comida general
    if any(c.startswith(k) for k in CAT_FOODISH_DEFAULT):
        return Verdict("10", "Food/food ingredient (Vertex 10); no special-class keyword or size trigger found.", "High", "food-default")
    return Verdict("10", "No specific rule matched; defaulted to Food (Vertex 10). Review manually.", "Low", "fallback")


RULE_ORDER = (r_nonfood, r_beverage, r_food)


def classify(it: Item) -> Verdict:
    for fn in RULE_ORDER:
        v = fn(it)
        if v:
            return v
    return Verdict("10", "No rule matched.", "Low", "none")
