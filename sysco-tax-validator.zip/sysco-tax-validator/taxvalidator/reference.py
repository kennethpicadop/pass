"""Carga de tablas de referencia: Vertex (codigos validos) y TaxLookup (CMIM -> codigo)."""
from __future__ import annotations

import csv
import os
import re
from dataclasses import dataclass, field

from .xlsx_io import load_workbook_any


def norm_code(code) -> str:
    return re.sub(r"\s+", " ", str(code)).strip() if code is not None else ""


def code_number(code: str) -> str:
    return norm_code(code).split(":")[0].strip()


@dataclass
class Reference:
    vertex_codes: dict = field(default_factory=dict)   # "10" -> "10:FOOD"
    taxlookup_cmim: dict = field(default_factory=dict)  # path -> {codes}
    taxlookup_cmim_counts: dict = field(default_factory=dict)  # path -> {code: count}
    cmim_map: dict = field(default_factory=dict)         # "07009099099" -> path (opcional)

    @property
    def has_cmim_map(self) -> bool:
        return bool(self.cmim_map)

    def full(self, number: str) -> str:
        """'56' -> '56:BAR MIXES' (nombre oficial de Vertex)."""
        return self.vertex_codes.get(str(number), str(number))

    def is_valid(self, code) -> bool:
        return code_number(code) in self.vertex_codes

    def lookup_for_cmim(self, cmim_norm: str):
        """Devuelve (path, {codes}) si hay traduccion numero->ruta y la ruta esta en TaxLookup."""
        path = self.cmim_map.get(cmim_norm) or (cmim_norm if cmim_norm in self.taxlookup_cmim else None)
        if not path:
            return None, None
        codes = self.taxlookup_cmim.get(path)
        return path, codes


def load_reference(ref_dir: str) -> Reference:
    ref = Reference()
    vx = os.path.join(ref_dir, "Vertex_Tax_Classification.xlsx")
    wb = load_workbook_any(vx)
    ws = wb["Product Groups"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] is None:
            continue
        num = str(row[0]).strip()
        ref.vertex_codes[num] = norm_code(row[2]) or f"{num}:{norm_code(row[1])}"

    tl = os.path.join(ref_dir, "TaxLookup.xlsx")
    wb = load_workbook_any(tl)
    ws = wb.worksheets[1]  # 1.TaxLookupTableCMIM: ruta | codigo | distinct | count
    for row in ws.iter_rows(min_row=1, values_only=True):
        if not row or not row[0] or not row[1]:
            continue
        path, code = norm_code(row[0]), norm_code(row[1])
        if ">" not in path:
            continue
        ref.taxlookup_cmim.setdefault(path, set()).add(code)
        ref.taxlookup_cmim_counts.setdefault(path, {})[code] = row[3]

    # Tabla opcional numero -> ruta (cuando alguien la consiga): reference/cmim_map.csv
    mp = os.path.join(ref_dir, "cmim_map.csv")
    if os.path.exists(mp):
        with open(mp, newline="", encoding="utf-8-sig") as fh:
            for r in csv.DictReader(fh):
                k = re.sub(r"\D", "", r.get("cmim_code", "")).zfill(11)
                ref.cmim_map[k] = norm_code(r.get("cmim_path", ""))
    return ref
