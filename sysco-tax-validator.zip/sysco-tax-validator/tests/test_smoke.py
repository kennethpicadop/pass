"""Pruebas rapidas: python -m unittest discover tests"""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from taxvalidator.reference import load_reference
from taxvalidator.engine import validate_row

REF = load_reference(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reference"))
IMG = {"IMG_0": "https://x/1"}

def row(**k):
    d = {"__row__": 2, "CMIM": "07000000000", **IMG}; d.update(k); return d

class T(unittest.TestCase):
    def code(self, **k): return validate_row(row(**k), REF)
    def test_still_water(self):
        r = self.code(TITLE="WATER SPRING 12OZ", CATEGORY="syy_cust_tax_water", **{"BEV-CARBONATION": "Non-carbonated", "BEV-JUICEPCT": "0", "BEV-CONCENTRATE": "Readytodrink"}, PRODUCTTAXCLASS="30:PURE STILL WATER")
        self.assertTrue(r.code_full.startswith("30:")); self.assertEqual(r.confidence, "High")
    def test_carbonated_soda_low_juice(self):
        r = self.code(TITLE="SODA COLA CASE OF 12", CATEGORY="syy_cust_tax_juice", **{"BEV-CARBONATION": "Carbonated", "BEV-JUICEPCT": "0"}, PRODUCTTAXCLASS="34:NCRB < 10% JCE")
        self.assertTrue(r.code_full.startswith("33:")); self.assertTrue(r.changed)
    def test_bar_mix(self):
        r = self.code(TITLE="MIX COCKTAIL MARGARITA CASE OF 6", CATEGORY="syy_cust_tax_syrups_L2", PRODUCTTAXCLASS="10:FOOD")
        self.assertTrue(r.code_full.startswith("56:"))
    def test_no_images(self):
        d = row(TITLE="RICE", CATEGORY="syy_cust_tax_pastaandrice", PRODUCTTAXCLASS="10:FOOD"); d.pop("IMG_0")
        r = validate_row(d, REF); self.assertTrue(r.no_images); self.assertTrue(r.justification.startswith("NO IMAGES"))
    def test_snack_over_1lb(self):
        r = self.code(TITLE="CHIPS TORTILLA BULK", CATEGORY="syy_cust_tax_chips", SIZE="2", SIZE_UOM="LB", PRODUCTTAXCLASS="11:SNACKS")
        self.assertTrue(r.code_full.startswith("10:"))
    def test_leading_zero(self):
        r = self.code(TITLE="RICE", CATEGORY="syy_cust_tax_pastaandrice", CMIM="7044015099", PRODUCTTAXCLASS="10:FOOD")
        self.assertIn("leading zero", r.justification)
if __name__ == "__main__": unittest.main()
