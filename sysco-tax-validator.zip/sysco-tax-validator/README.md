# Sysco Tax Validator (v1)

Valida archivos Excel de items (Food / Beverage) y recomienda el codigo de tax.

## Salida (en el mismo Excel, tres columnas juntas)
1. `Sales Tax Indicator Code - TAX Review` -> codigo recomendado
2. `TAX Review - Justification & Source` -> por que + fuente (definicion Vertex), resumido
3. `TAX Review - Confidence` -> High / Medium / Low
Mas una hoja `Validation Summary`. "NO IMAGES - item will be returned" aparece al inicio de la justificacion.

## Jerarquia de decision
1. Bloqueos: sin imagenes, codigo inexistente en Vertex, CMIM con cero perdido.
2. Que ES el item (Vertex): manda sobre la clase actual.
3. Contraste con TaxLookup (solo si hay traduccion CMIM numero -> ruta).
4. Si Vertex y TaxLookup no coinciden: se recomienda Vertex, confianza Low, marcado DISCREPANCY.
5. Falta informacion: se recomienda lo mas probable, confianza Low, y se dice que dato falta.

## Como usarla (Windows, sin activar venv)
- Doble clic: arrastra el .xlsx encima de `validar_archivo.bat`
- O: `python validate.py archivo.xlsx`  (instala antes: `python -m pip install -r requirements.txt`)

## Pendiente: TaxLookup
TaxLookup usa la ruta en texto del CMIM; los items traen el numero. Cuando consigas la tabla, guardala como
`reference/cmim_map.csv` con columnas `cmim_code,cmim_path`. No hay que cambiar codigo.

## Ajustar reglas
Palabras clave y reglas: `taxvalidator/rules.py`. Tablas de referencia: carpeta `reference/` (reemplaza los Excel para actualizarlas).
Pruebas: `python -m unittest discover tests`
