@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt --quiet
echo Abriendo la interfaz en tu navegador (http://127.0.0.1:8501). Cierra esta ventana para detenerla.
python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
pause
