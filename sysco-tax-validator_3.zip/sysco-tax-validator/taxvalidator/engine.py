"""Motor: combina reglas Vertex, TaxLookup, imagenes y el codigo actual del item."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .reference import Reference, code_number, norm_code
from .rules import Item, Verdict, classify
from .overrides import OverrideSet

IMG_FIELDS = ("IMG_0", "IMG_1", "IMG_A", "IMG_M", "IMG_LS")
LEVELS = ["Low", "Medium", "High"]

# Que dato o verificacion subiria la confianza, por regla (se agrega a la justificacion cuando no es High)
NEEDS = {
    "disposable-60": "confirm the item is a disposable/foodservice supply and not a food or packaging for resale",
    "cutlery": "confirm it is disposable utensils (Vertex 60-67 range) and the right sub-class",
    "napkin": "confirm it is a disposable napkin/paper good and the right sub-class",
    "trash": "confirm it is a trash/liner supply and the right sub-class",
    "glove": "confirm it is a disposable glove/foodservice supply and not a medical item (90-98)",
    "garnish": "confirm if it is edible garnish (food) or a decorative supply",
    "carryout": "confirm it is take-out packaging, not food",
    "diaper": "confirm product type from the label/description",
    "supplement": "check the label: a Supplement Facts panel means 18; a Nutrition Facts panel means food (10)",
    "supplies-general": "add a clearer description or category; confirm whether it is a supply (70-72) or another class",
    "coffee-loose": "confirm it is roasted/ground coffee or tea sold dry (Vertex 12) and not a ready-to-drink beverage",
    "coffee-milk": "confirm whether the product is made with milk (54) or without (55)",
    "tea-milk": "confirm whether the product is made with milk (52) or without (53)",
    "powder-tea": "confirm the product is a powder to reconstitute (51) vs. ground tea/coffee (12)",
    "water-carb-flav": "confirm carbonation and whether the water is sweetened/flavored",
    "water-flav": "confirm whether the water is sweetened (31) or not (30)",
    "juice-band": "fill in juice % (BEV-JUICEPCT) and carbonation so the band (33-46) can be confirmed",
    "bev-syrup": "confirm the product is a syrup/flavor additive (1C) vs. a beverage",
    "bev-conc": "confirm if it is a flavor additive (1C) or a concentrate that makes a beverage",
    "protein-shake": "confirm the label: Supplement Facts panel (18) or Nutrition Facts (10 / meal replacement 20)",
    "mocktail": "confirm whether it is a bar mixer (56) or a prepared non-alcoholic drink",
    "barmix": "confirm it is a mixer for cocktails (56)",
    "barmix-or-powder": "confirm the preparation form: ready mixer (56) or powder to reconstitute (50)",
    "condiment-bottle": "confirm the item is a condiment (15 applies only in some states, e.g. CO) vs. plain food (10)",
    "condiment-bulk": "confirm size/packaging to see if it is a condiment (15) or food (10)",
    "nuts-candy2": "confirm if it is candy (22) or a nut snack (11/10)",
    "snack-nosize": "add the unit size (oz/lb) to confirm the 1 lb limit for snacks (11)",
    "snack-big": "confirm unit size (over 1 lb is food 10, not snack 11)",
    "candy-flour": "confirm whether it contains flour (food 10) or is candy (21-25)",
    "cocoa": "confirm if it is cocoa powder for baking (10) or a beverage mix (51)",
    "cocoa-bev": "confirm if it is a drink mix (51) or baking cocoa (10)",
    "hotchoc": "confirm if it is a powder drink mix (51) or a ready beverage",
    "instant": "confirm the product form (powder/instant) to pick 51 vs. 12",
    "mints": "confirm if it is candy (21-25) or breath mints classified differently",
    "icecream": "add the unit size to confirm the pint-or-smaller rule (17)",
    "fallback": "add a clearer title/category; no rule matched, so this is only the default",
    "none": "add a clearer title/category; no rule matched",
}


@dataclass
class Result:
    row: int
    code_full: str
    justification: str
    confidence: str
    changed: bool
    no_images: bool
    discrepancy: bool
    rule: str
    notes: list = field(default_factory=list)
    taxlookup_applied: bool = False
    override_id: str = ""


def has_images(d: dict) -> bool:
    for f in IMG_FIELDS:
        v = d.get(f)
        if v is not None and str(v).strip() not in ("", "N/A", "n/a"):
            return True
    return False


def norm_cmim(v):
    """Devuelve (cmim_normalizado, nota). Repone el cero inicial perdido por Excel."""
    if v is None or str(v).strip() == "":
        return None, None
    s = str(v).strip()
    if ">" in s:
        return norm_code(s), None
    digits = re.sub(r"\D", "", s)
    if len(digits) == 10:
        return digits.zfill(11), "CMIM had 10 digits (leading zero lost); read as 11."
    return digits, None


def _shift(conf: str, step: int) -> str:
    return LEVELS[max(0, min(2, LEVELS.index(conf) + step))]


def validate_row(d: dict, ref: Reference, ov: OverrideSet | None = None) -> Result:
    it = Item(d)
    v: Verdict = classify(it)
    override_id = ""
    if ov is not None:
        o = ov.apply(it, v)
        if o:
            base = ref.full(v.code)
            v = Verdict(o.then_code, f"Override {o.id}: {o.reason} (base rule would give {base}).", o.conf, "override:" + o.id)
            override_id = o.id
    notes = []
    code_full = ref.full(v.code)
    conf = v.conf

    # codigo actual
    cur = it.current
    cur_num = code_number(cur) if cur else ""
    if not cur:
        lead = "No current code. "
    elif not ref.is_valid(cur):
        lead = f"Current code '{cur}' is not a valid Vertex class. "
    elif cur_num == v.code:
        lead = "Confirms current code. "
    else:
        lead = f"Change from {norm_code(cur)}. "
    changed = bool(cur) and cur_num != v.code

    # TaxLookup
    cmim, cmim_note = norm_cmim(d.get("CMIM"))
    if cmim_note:
        notes.append(cmim_note)
    path, codes = ref.lookup_for_cmim(cmim) if cmim else (None, None)
    applied = codes is not None
    discrepancy = False
    tl_txt = ""
    if applied:
        codes_n = {code_number(c) for c in codes}
        if v.code in codes_n:
            conf = _shift(conf, +1)
            tl_txt = " TaxLookup agrees."
        else:
            discrepancy = True
            conf = "Low"
            tl_txt = (" DISCREPANCY Vertex vs TaxLookup: TaxLookup suggests "
                      + " / ".join(sorted(norm_code(c) for c in codes)) + "; Vertex rule kept.")

    # imagenes
    no_img = not has_images(d)
    prefix = "NO IMAGES - item will be returned. " if no_img else ""

    just = prefix + lead + v.why + tl_txt
    if discrepancy:
        just += " To resolve: check which source is right for this CMIM and adjust the rule/map."
    elif conf != "High":
        need = NEEDS.get(v.rule.split(":")[0]) or ("verify the title, category and size against the Vertex definition"
                                                   if not v.rule.startswith("override") else "")
        if need:
            just += f" To raise confidence: {need}."
    if cmim_note:
        just += " " + cmim_note
    if not cmim and not applied:
        just += " (CMIM blank.)"
    return Result(d["__row__"], code_full, just.strip(), conf, changed, no_img, discrepancy, v.rule, notes, applied, override_id)


def validate_rows(rows: list[dict], ref: Reference, ov: OverrideSet | None = None) -> list[Result]:
    return [validate_row(r, ref, ov) for r in rows]
