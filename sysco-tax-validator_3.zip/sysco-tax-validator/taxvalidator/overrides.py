"""Overrides firmados.

Las reglas de excepcion NO viven en el codigo ni en ninguna pantalla. Viven en
`reference/overrides.dat`, un paquete firmado con la llave privada del administrador
(carpeta `admin/`, que NO se distribuye al equipo). La herramienta solo trae la llave
publica: puede verificar el paquete pero no crear ni modificar overrides.

- Paquete ausente  -> corre sin overrides y lo indica en el resumen.
- Firma invalida   -> se detiene (el archivo fue alterado o no es del administrador).
"""
from __future__ import annotations

import base64
import json
import os
import zlib
from dataclasses import dataclass, field

from .rules import Item, Verdict, has

DAT = "overrides.dat"
PUB = "overrides_public.pem"


class OverridesInvalid(Exception):
    pass


@dataclass
class Override:
    id: str
    then_code: str
    reason: str
    conf: str = "High"
    when_code: list = field(default_factory=list)       # codigo que recomendo el motor (opcional)
    category_any: list = field(default_factory=list)    # fragmentos de CATEGORY (opcional)
    title_any: list = field(default_factory=list)       # alguna palabra/frase en el titulo
    title_all: list = field(default_factory=list)       # todas
    title_none: list = field(default_factory=list)      # ninguna

    def matches(self, it: Item, engine_code: str) -> bool:
        if self.when_code and engine_code not in self.when_code:
            return False
        if self.category_any and not any(c in it.cat for c in self.category_any):
            return False
        if self.title_any and not has(it.title, self.title_any):
            return False
        if self.title_all and not all(has(it.title, [w]) for w in self.title_all):
            return False
        if self.title_none and has(it.title, self.title_none):
            return False
        return True


@dataclass
class OverrideSet:
    items: list = field(default_factory=list)
    loaded: bool = False
    note: str = ""

    def apply(self, it: Item, v: Verdict):
        for o in self.items:
            if o.matches(it, v.code):
                return o
        return None


def _split(x):
    return [s.strip().upper() for s in str(x or "").replace(",", ";").split(";") if s.strip()]


def load_overrides(ref_dir: str) -> OverrideSet:
    dat, pub = os.path.join(ref_dir, DAT), os.path.join(ref_dir, PUB)
    if not os.path.exists(dat):
        return OverrideSet(note="No override package found; running with base rules only.")
    if not os.path.exists(pub):
        raise OverridesInvalid("Falta la llave publica de overrides.")
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        pkg = json.load(open(dat, encoding="utf-8"))
        payload = base64.b64decode(pkg["payload"])
        sig = base64.b64decode(pkg["sig"])
        load_pem_public_key(open(pub, "rb").read()).verify(sig, payload)
    except ImportError as e:
        raise OverridesInvalid("Falta el paquete 'cryptography' (python -m pip install -r requirements.txt).") from e
    except (InvalidSignature, KeyError, ValueError, json.JSONDecodeError) as e:
        raise OverridesInvalid("El paquete de overrides no tiene una firma valida (fue alterado o no es del "
                               "administrador). Contacta al administrador.") from e
    rows = json.loads(zlib.decompress(payload).decode("utf-8"))
    items = []
    for r in rows:
        if str(r.get("active", "Y")).strip().upper() not in ("Y", "YES", "1", "TRUE", "SI"):
            continue
        items.append(Override(
            id=str(r["id"]).strip(), then_code=str(r["then_code"]).strip(), reason=str(r.get("reason", "")).strip(),
            conf=(str(r.get("confidence") or "High").strip().capitalize()),
            when_code=[c.split(":")[0] for c in _split(r.get("when_code"))],
            category_any=[c.lower() for c in _split(r.get("category_any"))],
            title_any=_split(r.get("title_any")), title_all=_split(r.get("title_all")),
            title_none=_split(r.get("title_none"))))
    return OverrideSet(items=items, loaded=True, note=f"{len(items)} signed override rule(s) loaded.")
