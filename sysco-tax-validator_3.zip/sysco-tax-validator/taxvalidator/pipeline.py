"""Funciones compartidas por la interfaz y la linea de comandos."""
from __future__ import annotations

import io
import os
import tempfile

from .engine import Result, validate_rows
from .writer import write_output
from .xlsx_io import load_workbook_any, read_sheet


def detect_kind(rows: list[dict]) -> str:
    if not rows:
        return "Unknown"
    bev = sum(1 for r in rows if str(r.get("BEV-CARBONATION") or "").strip() or str(r.get("BEV-JUICEPCT") or "").strip())
    return "Beverage" if bev / len(rows) >= 0.3 else "Food"


def run_bytes(name: str, data: bytes, ref, ov):
    """Valida un archivo subido (bytes). Devuelve dict con filas, resultados y ruta temporal."""
    tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
    tmp.write(data)
    tmp.close()
    wb = load_workbook_any(tmp.name)
    headers, rows = read_sheet(wb.worksheets[0])
    if "PRODUCTTAXCLASS" not in headers:
        os.unlink(tmp.name)
        raise ValueError("No encuentro la columna PRODUCTTAXCLASS en la fila 1.")
    results = validate_rows(rows, ref, ov)
    return {"name": name, "tmp": tmp.name, "headers": headers, "rows": rows, "results": results,
            "kind": detect_kind(rows)}


def build_workbook_bytes(entry: dict, results: list[Result], ref, ov) -> bytes:
    buf = io.BytesIO()
    write_output(entry["tmp"], buf, entry["headers"], results, entry["name"], ref.has_cmim_map,
                 override_note=ov.note)
    return buf.getvalue()
