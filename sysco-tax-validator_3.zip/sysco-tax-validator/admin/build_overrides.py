"""SOLO PARA EL ADMINISTRADOR. No distribuir esta carpeta al equipo.

Uso:  python admin/build_overrides.py
  1. Edita admin/overrides_source.csv (tus reglas de excepcion).
  2. Corre este script: crea/usa tu llave privada (admin/admin_private.pem), firma las reglas y genera
     reference/overrides.dat + reference/overrides_public.pem.
  3. Entrega al equipo la carpeta SIN 'admin/'.
Guarda admin_private.pem en un lugar seguro: sin ella nadie puede crear overrides validos.

Columnas del CSV (separa varios valores con ;):
  id, active (Y/N), when_code (codigo que recomienda el motor, opcional), category_any (fragmento de CATEGORY),
  title_any (alguna palabra), title_all (todas), title_none (ninguna), then_code (codigo final), confidence, reason
"""
import base64, csv, json, os, sys, zlib
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PRIV = os.path.join(HERE, "admin_private.pem")
SRC = os.path.join(HERE, "overrides_source.csv")
OUT = os.path.join(ROOT, "reference")

if os.path.exists(PRIV):
    key = serialization.load_pem_private_key(open(PRIV, "rb").read(), password=None)
else:
    key = Ed25519PrivateKey.generate()
    open(PRIV, "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                              serialization.NoEncryption()))
    print("Llave privada creada:", PRIV, "(guardala a salvo, no la compartas)")

rows = list(csv.DictReader(open(SRC, newline="", encoding="utf-8-sig")))
ids = [r["id"] for r in rows]
if len(ids) != len(set(ids)):
    sys.exit("IDs repetidos en el CSV")
payload = zlib.compress(json.dumps(rows, ensure_ascii=False).encode("utf-8"), 9)
sig = key.sign(payload)
os.makedirs(OUT, exist_ok=True)
json.dump({"payload": base64.b64encode(payload).decode(), "sig": base64.b64encode(sig).decode()},
          open(os.path.join(OUT, "overrides.dat"), "w", encoding="utf-8"))
open(os.path.join(OUT, "overrides_public.pem"), "wb").write(
    key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
print(f"{len(rows)} regla(s) firmadas -> reference/overrides.dat")
