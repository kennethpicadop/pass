"""SOLO ADMIN. Crea sysco-tax-validator_TEAM.zip sin la carpeta admin/ (sin llave privada ni CSV de overrides).
Antes: python admin/build_overrides.py  (para que reference/overrides.dat este actualizado)."""
import os, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(os.path.dirname(ROOT), "sysco-tax-validator_TEAM.zip")
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for d, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x not in ("admin", "__pycache__", ".git")]
        for f in files:
            p = os.path.join(d, f)
            z.write(p, os.path.join(os.path.basename(ROOT), os.path.relpath(p, ROOT)))
print("Creado:", OUT)
