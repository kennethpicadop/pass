# Sysco Tax Validator (v1)

Valida archivos Excel de items (Food / Beverage) y recomienda el codigo de tax.

## Salida (en el mismo Excel, tres columnas juntas)
1. `Sales Tax Indicator Code - TAX Review` -> codigo recomendado
2. `TAX Review - Justification & Source` -> por que + fuente (definicion Vertex), resumido
3. `TAX Review - Confidence` -> High / Medium / Low
Mas una hoja `Validation Summary`. "NO IMAGES - item will be returned" aparece al inicio de la justificacion.

## Jerarquia de decision
1. Bloqueos: sin imagenes, codigo inexistente en Vertex, CMIM con cero perdido.
2. Que ES el item (Vertex): manda sobre la clase actual.
3. Contraste con TaxLookup (solo si hay traduccion CMIM numero -> ruta).
4. Si Vertex y TaxLookup no coinciden: se recomienda Vertex, confianza Low, marcado DISCREPANCY.
5. Falta informacion: se recomienda lo mas probable, confianza Low, y se dice que dato falta.

## Como usarla (Windows, sin activar venv)
- Doble clic: arrastra el .xlsx encima de `validar_archivo.bat`
- O: `python validate.py archivo.xlsx`  (instala antes: `python -m pip install -r requirements.txt`)

## Pendiente: TaxLookup
TaxLookup usa la ruta en texto del CMIM; los items traen el numero. Cuando consigas la tabla, guardala como
`reference/cmim_map.csv` con columnas `cmim_code,cmim_path`. No hay que cambiar codigo.

## Ajustar reglas
Palabras clave y reglas: `taxvalidator/rules.py`. Tablas de referencia: carpeta `reference/` (reemplaza los Excel para actualizarlas).
Pruebas: `python -m unittest discover tests`

## Overrides (reglas de excepcion ocultas)
Las excepciones (ej. "bar mix con SALT es Food", "meat snack es Food") NO estan en el codigo ni en ninguna pantalla.
- Se escriben en `admin/overrides_source.csv` y se firman con `python admin/build_overrides.py`
  (la primera vez crea tu llave privada `admin/admin_private.pem`: guardala a salvo, no la compartas).
- Eso genera `reference/overrides.dat` (firmado) y `reference/overrides_public.pem`.
- La herramienta solo trae la llave publica: puede verificar, pero nadie puede crear ni cambiar overrides sin tu llave.
  Si el paquete se altera, la herramienta se detiene con un error. Si falta, corre solo con las reglas base.
- Un override se aplica despues de las reglas base; la justificacion dice "Override OV-00X: motivo".
- Para el equipo: `python admin/make_team_package.py` crea un zip SIN la carpeta admin/.
Limite honesto: protege contra cambios casuales y detecta alteraciones; quien tenga acceso al codigo y a la llave
publica podria reemplazarlas. El candado total llega cuando la herramienta viva en un servidor.

## Interfaz (colores Sysco)

Doble clic en `abrir_interfaz.bat` (o `python -m streamlit run app.py`). Se abre en el navegador, solo en tu computadora (127.0.0.1).
Flujo: subir Excel -> Validate -> revisar la cola (por defecto Medium + Low) -> aprobar o poner "Your code" -> Generate reviewed workbook -> descargar.
La interfaz no muestra ni permite editar los overrides; esos viven en el paquete firmado `reference/overrides.dat`.
