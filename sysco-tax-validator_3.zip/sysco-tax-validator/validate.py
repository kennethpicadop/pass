"""Uso:  python validate.py archivo.xlsx [otro.xlsx ...] [--out-dir carpeta] [--ref-dir reference]

Genera <archivo>_VALIDATED.xlsx con:
  - Sales Tax Indicator Code - TAX Review  (codigo recomendado)
  - TAX Review - Justification & Source     (por que + fuente, resumido)
  - TAX Review - Confidence                 (High / Medium / Low)
"""
import argparse
import os
import sys
import warnings
from collections import Counter

warnings.filterwarnings("ignore")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from taxvalidator.engine import validate_rows  # noqa: E402
from taxvalidator.overrides import OverridesInvalid, load_overrides  # noqa: E402
from taxvalidator.reference import load_reference  # noqa: E402
from taxvalidator.writer import write_output  # noqa: E402
from taxvalidator.xlsx_io import load_workbook_any, read_sheet  # noqa: E402


def process(path: str, out_dir: str, ref, ov) -> str:
    wb = load_workbook_any(path)
    headers, rows = read_sheet(wb.worksheets[0])
    if "PRODUCTTAXCLASS" not in headers:
        raise SystemExit(f"{os.path.basename(path)}: no encuentro la columna PRODUCTTAXCLASS. "
                         "Revisa que la fila 1 tenga los encabezados.")
    results = validate_rows(rows, ref, ov)
    base = os.path.splitext(os.path.basename(path))[0]
    out = os.path.join(out_dir, base + "_VALIDATED.xlsx")
    write_output(path, out, headers, results, os.path.basename(path), ref.has_cmim_map, override_note=ov.note)
    c = Counter(r.confidence for r in results)
    print(f"{os.path.basename(path)}: {len(results)} filas | High {c['High']} / Medium {c['Medium']} / Low {c['Low']} | "
          f"cambios {sum(r.changed for r in results)} | sin imagen {sum(r.no_images for r in results)} | "
          f"discrepancias {sum(r.discrepancy for r in results)} | overrides {sum(bool(r.override_id) for r in results)}")
    print("  -> " + out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--ref-dir", default=os.path.join(HERE, "reference"))
    a = ap.parse_args()
    ref = load_reference(a.ref_dir)
    try:
        ov = load_overrides(a.ref_dir)
    except OverridesInvalid as e:
        raise SystemExit("ERROR: " + str(e))
    bad = [o.id for o in ov.items if not ref.is_valid(o.then_code)]
    if bad:
        raise SystemExit("ERROR: overrides con codigo inexistente en Vertex: " + ", ".join(bad))
    print(ov.note)
    for f in a.files:
        out_dir = a.out_dir or os.path.dirname(os.path.abspath(f))
        os.makedirs(out_dir, exist_ok=True)
        process(f, out_dir, ref, ov)


if __name__ == "__main__":
    main()
